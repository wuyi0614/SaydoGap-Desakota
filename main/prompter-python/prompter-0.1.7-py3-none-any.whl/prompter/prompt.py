# Prompt utils for LLM.  
#
# Created at 20/04/2025, @Yi WU
#
# Updated at 17/08/2025, @Yi WU
# 

import os
import instructor

from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv

from pydantic import BaseModel
from openai import OpenAI
from ollama import Client
from json_repair import json_repair

from prompter.base import logger, make_prompt_cache, write_to_jsonl
from prompter.middleware import get_chunks_from_text
from prompter.items import BaseChatItem, PromptResponse

# load the environment variables
load_dotenv()


class BaseChat:
    
    """A base class for chat."""

    provider: str
    client: OpenAI | Client
    model: str
    memory: list[dict]

    verbose: bool
    chat_model: BaseChatItem
    json_model: BaseModel = None

    def __init__(self,
                 which_model: str,
                 json_model: BaseModel = None,
                 multi_round: bool = False,
                 verbose: bool = False,
                 memory: list[dict] = None,
                 **kwargs):
        """Initialize a chat model with a given LLM model with/without structured response.
        
        Parameters
        ----------
        which_model: str
            The model to use, e.g., 'ollama+qwen3:32b' or 'openai+gpt-4o-mini'
        json_model: BaseModel, optional
            The structured response model (derived from pydantic) to use, by default None
        multi_round: bool, optional
            Whether to enable multi-round chatting, by default False
        verbose: bool, optional
            Whether to enable verbose logging, by default False
        memory: list[dict], optional
            The memory of messages to restore the chat, by default None
        **kwargs: dict, optional
            Additional keyword arguments
        """
        self.chat_model, self.client, self.provider, self.model = self.get_client(which_model)
        if memory is not None:
            self.chat_model.messages = memory
            self.memory = memory
        else:
            self.chat_model.messages = []
            self.memory = []

        self.json_model = json_model
        self.multi_round = multi_round
        self.verbose = verbose

    @staticmethod
    def get_client(which_model: str) -> tuple[BaseChatItem, OpenAI, str]:
        """Get a client and a model by specifying the LLM model.

        Parameters
        ----------
        which_model: str
            The model to use, e.g., 'ollama+qwen3:32b' or 'openai:gpt-4o-mini'

        Returns
        -------
        client: OpenAI | Client
            The client of the LLM.
        model: str
            The model of the LLM.
        """
        from prompter.items import OllamaChatItem, OpenAIChatItem, NonOpenAIChatItem

        provider, model = which_model.split('+')
        assert isinstance(provider, str) and isinstance(model, str) and len(model) > 0, f"Invalid model: {which_model}, which should be like 'openai+gpt-4o-mini' or 'ollama+qwen3:32b'"
        
        if provider == 'openai':
            chat_model = OpenAIChatItem(id='', text='', model=model)
            client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"), base_url=os.getenv("LLM_OPENAI_ENTRYPOINT"))

        elif provider == 'ollama':
            chat_model = OllamaChatItem(id='', text='', model=model)
            # client = OpenAI(api_key=os.getenv("OLLAMA_API_KEY"), base_url=os.getenv("LLM_OLLAMA_ENTRYPOINT"))
            client = Client(host=os.getenv("LLM_OLLAMA_ENTRYPOINT"))

        elif provider == 'dashscope':
            chat_model = NonOpenAIChatItem(id='', text='', model=model)
            client = OpenAI(api_key=os.getenv("DASHSCOPE_API_KEY"), base_url=os.getenv("LLM_DASHSCOPE_ENTRYPOINT"))

        elif provider == 'deepseek':
            chat_model = NonOpenAIChatItem(id='', text='', model=model)
            client = OpenAI(api_key=os.getenv("DEEPSEEK_API_KEY"), base_url=os.getenv("LLM_DEEPSEEK_ENTRYPOINT"))

        else:
            raise ValueError(f"Unavailable model: {which_model} in .env!")

        return chat_model, client, provider, model

    @staticmethod
    def _chat(client: OpenAI | Client, provider: str, item: BaseChatItem, json_model: BaseModel = None) -> list[dict[str, str]]:
        """The generic chat function compatible with various LLM clients."""
        if provider == 'ollama':
            item_dict = item.model_dump(exclude=['id', 'meta'])
            if json_model is not None:
                item_dict['format'] = json_model.model_json_schema()
                response = client.chat(**item_dict)
                content = response.message.content
                try:
                    repaired = json_repair.repair_json(content)
                    content = json_model.model_validate_json(repaired)
                    content = content.model_dump_json()
                except Exception as e:
                    logger.error(f'Unverified JSON model: {repaired}')
            else:
                response = client.chat(**item_dict)
                content = response.message.content

        elif provider == 'openai':
            # `format` is not supported for the openai client
            if json_model is not None:
                item_dict = item.model_dump(exclude=['id', 'meta', 'stream'])
                item_dict['response_format'] = json_model
                response = client.beta.chat.completions.parse(**item_dict)
                # content = response.choices[0].message.content  # ... unstructured response
                content = response.choices[0].message.parsed.model_dump_json()
            else:
                item_dict = item.model_dump(exclude=['id', 'meta'])
                response = client.chat.completions.create(**item_dict)
                content = response.choices[0].message.content

        else:  # use instructor to parse the response
            client = instructor.from_openai(client)
            item_dict = item.model_dump(exclude=['id', 'meta'])
            if json_model is not None:
                item_dict['response_model'] = json_model
                response = client.chat.completions.create(**item_dict)
                content = response.model_dump_json()
            else:
                response = client.chat.completions.create(**item_dict)
                content = response.choices[0].message.content
    
        # append the assistant's response and make sure `content` is a BaseModel
        return [{'role': 'assistant', 'content': content}]
    
    @staticmethod
    def _prompt(content: str, role: str) -> list[dict[str, str]]:
        return [{"role": role, "content": content}]
    
    def chat(self,
             role: str,
             text_or_prompted_text: str,
             jsonify: bool = False) -> list[dict[str, str]]:
        """Call this function once and only proceed with one text. By default, `chat` supports multi-round chatting.
        Parameters
        ----------
        role : str
            The role of the message sender, e.g., "user" or "assistant".
        text_or_prompted_text : str
            The content of the message to send, or a previously prompted text.
        jsonify : bool, optional
            If True, expects a JSON-structured response using the configured json_model; if False, returns regular string content.
        
        Returns
        -------
        BaseChatItem
            The processed BaseChatItem (or the other varaints).
        """
        import copy
        
        # deepcopy the memory to avoid modifying the original memory and allow multi-round chatting
        self.memory = copy.deepcopy(self.chat_model.messages)
        msg = self._prompt(content=text_or_prompted_text, role=role)
        self.chat_model.messages.append(msg[0])
        one = self._chat(self.client, self.provider, self.chat_model, self.json_model if jsonify else None)
        # note: this item is identical but deeply copied from the chat model
        if self.verbose:
            make_prompt_cache(one)
        
        if self.multi_round or role == 'system':
            self.chat_model.messages += one
        else:  # single round: every time rolling back to the initial messages
            self.chat_model.messages = copy.deepcopy(self.memory)
        
        return one


class BasePromptModel(BaseChat):

    """The BasePromptModel object"""
    
    ts: str
    prompted: bool = False
    thinking: bool = False

    def __init__(self, 
                 which_model: str,
                 system_prompt: str,
                 thinking: bool = False,
                 multi_round: bool = False,
                 memory: list[dict] = None,
                 json_model: BaseModel = None,
                 verbose: bool = False,
                 **kwargs):
        """Initialize the prompt model
        
        Parameters
        ----------
        which_model: str
            The model to use, e.g., 'ollama+qwen3:32b' or 'openai+gpt-4o-mini'
        system_prompt: str
            The system prompt to use
        thinking: bool, optional
            Whether to enable thinking, by default False
        multi_round: bool, optional
            Whether to enable multi-round chatting, by default False
        memory: list[dict], optional
            The memory to use, by default None
        json_model: BaseModel, optional
            The structured response model (derived from pydantic) to use, by default None
        verbose: bool, optional
            Whether to enable verbose logging, by default False
        **kwargs: dict, optional
            Additional keyword arguments to pass to the parent class
        """
        
        super().__init__(which_model, json_model, multi_round, verbose, **kwargs)
        # use the system prompt to initialize the chat model
        self.thinking = thinking
        if self.provider == 'ollama' and not self.thinking:
            self.chat_model.think = False

        self.update_system_prompt(prompt=system_prompt)
        # use the memory to inform the chat model
        if memory is not None:
            self.chat_model.messages = memory

    @staticmethod
    def _ts() -> str:
        """Get the timestamp of the current time"""
        return datetime.now().strftime("%H%M%S")

    @staticmethod
    def _chunk(text: str, 
               tokenizer_model: str | None = None, 
               overlap: int = 0, 
               min_length: int = 24, 
               max_tokens: int = 512) -> list[str]:
        """Get the chunks from the text
        
        Parameters
        ----------
        text : str
            The text to chunk
        tokenizer_model : str | None, optional
            The tokenizer model to use, e.g., [hf:bert-base-uncased|tiktoken:gpt-4o-mini]; by default None
        overlap : int, optional
            The overlap of the text chunks, by default 0
        min_length : int, optional
            The minimum length of the text chunks, by default 24
        max_tokens : int, optional
            The maximum number of tokens to use, by default 512

        Returns
        -------
        list[str]
            The text chunks
        """
        return get_chunks_from_text(text, tokenizer_model, overlap, min_length, max_tokens)

    @staticmethod
    def _export(response: PromptResponse, outfile: Path, overwrite: bool = False) -> dict:
        """Export the response to a given file"""
        write_to_jsonl(response.model_dump(), outfile, overwrite=overwrite)
        return response.model_dump()

    def update_system_prompt(self, prompt: str) -> None:
        """Use a new system prompt to update the system prompt"""
        self.system_prompt = prompt
        if len(self.chat_model.messages) > 0:
            logger.warning('Updating system prompt will clear the previous chat history regardless of multi-round mode!')
        
        prompt = prompt if self.thinking else prompt + '/no_think'
        # use `chat` to get responses from the bot and update the chat history
        return self.chat(text_or_prompted_text=prompt, role='system', jsonify=False)
    
    def prompt(self, text: str) -> PromptResponse:
        """Implement a prompted or not prompted chat with/without structured response.
        
        Parameters
        ----------
        text : str
            The original text or the **prompted text**

        Returns
        -------
        PromptResponse
        """
        if not self.thinking and not text.endswith('no_think'):
            text += '/no_think'

        jsonify = False if self.json_model is None else True
        one = self.chat(text_or_prompted_text=text, role='user', jsonify=jsonify)
        return PromptResponse(id=self.chat_model.id, response=one[0]['content'], meta=self.chat_model.meta)
    
    def next(self, system_prompt: str = None) -> None:
        """Reset the chat model and update the system prompt"""
        if system_prompt is not None:
            self.update_system_prompt(system_prompt)

    def close(self) -> None:
        """Close the chat"""
        self.client.close()


class TranslationPromptModel(BasePromptModel):
    """Translation model does not need system prompt"""
    def __init__(self,
                 which_model: str,
                 thinking: bool = False,
                 multi_round: bool = False,
                 memory: list[dict] = None,
                 json_model: BaseModel = None,
                 verbose: bool = False,
                 **kwargs):
        
        # customised initialization
        self.chat_model, self.client, self.provider, self.model = self.get_client(which_model)
        if memory is not None:
            self.chat_model.messages = memory
            self.memory = memory
        else:
            self.chat_model.messages = []
            self.memory = []

        self.json_model = json_model
        self.multi_round = multi_round
        self.verbose = verbose
        self.thinking = True
        if self.provider == 'ollama' and not self.thinking:
            self.chat_model.think = False
        # use the memory to inform the chat model
        if memory is not None:
            self.chat_model.messages = memory
    
        
if __name__ == '__main__':
    # 用真实API测试单轮/多轮对话的模型
    from dotenv import load_dotenv
    load_dotenv()
    
    # 测试 BasePromptModel 标准化输出：定义 StructuredOutput 类并测试不同模型输出
    from pydantic import BaseModel, Field
    from prompter.prompt import BasePromptModel, TranslationPromptModel

    class StructuredOutput(BaseModel):
        name: str = Field(..., description="产品名称")
        length_cm: float = Field(..., description="长度（厘米）")
        feature: str = Field(..., description="产品主要特点描述")

    test_text = (
        " DVI 24 + 1 Pin Male to VGA 15 Pin Female Cable Adapter Converter Connector \n\n"
        " This adapter connects DVI compatible systems with a DVI-D output to VGA equipped monitors and displays \n"
        "Ideal for your office, home entertainment display, conference rooms and much more \n"
        "Plug and Play. Stable and reliable signal transmission \n"
        "Provides you a dependable picture \n"
        "Provides a simple way to output user-generated content, such as presentations and work documents \n"
        "Also increases your productivity by extending your computer's desktop onto to a secondary monitor, doubling available workspace \n"
        "Length: 23cm "
    )

    models = [
        'openai+gpt-4o-mini',
        'dashscope+qwen-plus',
        'ollama+qwen3:4b',
        'deepseek+deepseek-chat'
    ]

    for model in models:
        print(f"\n==== 测试模型: {model} ====")
        prompt_model = BasePromptModel(
            which_model=model,
            system_prompt='You are a product description parser. You will be given a product description and you will need to parse it into a structured output.',
            json_model=StructuredOutput,
            thinking=False,
            multi_round=False,
            verbose=True
        )
        response = prompt_model.prompt(test_text)
        print("标准化输出(StructuredOutput):", response.response)
        print("聊天消息历史:", prompt_model.chat_model.messages)
    
    # 测试多轮对话
    # 再增加2个产品的信息通过多轮对话的方式来测试模型

    multi_turn_products = [
        " HDMI to VGA Adapter Male to Female Converter with Audio Cable \n\n"
        "Connects HDMI devices to VGA displays. Supports resolutions up to 1080p Full HD. "
        "Includes 3.5mm audio out for sound. Compact and easy to carry.",
        " USB Type-C to USB 3.0 Adapter OTG Converter Silver \n\n"
        "Convert USB-C port to standard USB-A. Supports fast data transfer up to 5Gbps. "
        "Plug and play, no drivers needed. Aluminum alloy shell, durable and stylish."
    ]

    # 选择一个模型进行多轮对话测试（如第一个模型）
    # 多轮对话测试所有上面提到的模型
    for multi_turn_model in models:
        print(f"\n==== 多轮对话测试 模型: {multi_turn_model} ====")
        multi_turn_prompt = BasePromptModel(
            which_model=multi_turn_model,
            system_prompt='You are a product description parser. You will be given a product description and you will need to parse it into a structured output.',
            json_model=StructuredOutput,
            thinking=False,
            multi_round=True,
            verbose=True
        )
        # 轮1：第一个产品
        resp1 = multi_turn_prompt.prompt(multi_turn_products[0])
        print("产品1标准化输出:", resp1.response)
        print("消息历史:", multi_turn_prompt.chat_model.messages)
        # 轮2：第二个产品
        resp2 = multi_turn_prompt.prompt(multi_turn_products[1])
        print("产品2标准化输出:", resp2.response)
        print("消息历史:", multi_turn_prompt.chat_model.messages)


    # 测试 TranslationPromptModel
    translation_prompt = TranslationPromptModel(
        which_model='dashscope+qwen-mt-flash',
        thinking=True,
        multi_round=False,
        verbose=True
    )
    text = 'Please translate the following product name into English: Thuốc Nhuộm Tóc Phủ Bạc Tại Nhà Bigen Xám - Phủ Bạc Thảo Dược Dưỡng Tóc Mềm Mượt 80ml'
    response = translation_prompt.prompt(text)
    print("翻译结果:", response.response)
    