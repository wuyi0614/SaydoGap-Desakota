# Base classes for LLM & Python I/O.  
# 
# Created at 20/04/2025, @Yi WU
#
# Updated at 17/08/2025, @Yi WU
# 

from typing import Any
from pydantic import BaseModel, Field


class BaseChatItem(BaseModel):

    """A base model for chat items."""
    
    model: str = Field(default='', description='The name of LLM model for use, e.g. "gpt-4o"')
    messages: list[dict] = Field(default=[], description='Chat messages with LLM, each message is a dict with keys "role" and "content"')
    stream: bool = Field(default=False, description='Whether to stream the response')

    id: str = Field(default='default-id', description='The id of the chat item')
    meta: dict[Any, Any] = Field(default={}, description='Metadata of the item, e.g., report_name, company_name, year, page_idx, etc.')

    def __init__(self, **kwargs):
        """Initialize the chat item"""
        super().__init__(**kwargs)
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
            else:
                self.meta[key] = value
    
    def reset(self):
        """
        Reset the attributes of the item to their initial state.
        """
        # Reset to Pydantic BaseModel defaults for all fields except id and text
        for name, field in self.__class__.model_fields.items():
            default = field.get_default()
            # For mutable defaults, create a new instance to avoid shared reference
            if isinstance(default, (dict, list)):
                value = default.copy()
            else:
                value = default
            setattr(self, name, value)
        # Clear meta if additional keys were added by kwargs
        self.meta = {}


class OllamaChatItem(BaseChatItem):
    
    """A chat item for ollama."""
    
    format: Any = Field(default=None, description='The format of the response')
    think: bool = Field(default=True, description='Allow the LLM to think (reason) or not')
    options: dict = Field(default={'keep_alive': '0s'}, description='Options for the chat, e.g. "keep_alive" to avoid memory corruption')


class OpenAIChatItem(BaseChatItem):
    
    """A chat item for openai (or other variants)"""
    
    temperature: float = Field(default=0.1, description='The temperature of the response')
    response_format: Any = Field(default=None, description='The format of the response, e.g. "json_schema')


class NonOpenAIChatItem(BaseChatItem):
    
    """A chat item for non-openai clients"""

    temperature: float = Field(default=0.1, description='The temperature of the response')
    response_model: Any = Field(default=None, description='The structured response model for LLM output')


class PromptResponse(BaseModel):

    """The PromptResponse object"""

    id: str  # the same as the id of the PromptItem
    response: Any
    meta: dict[Any, Any] = {}
