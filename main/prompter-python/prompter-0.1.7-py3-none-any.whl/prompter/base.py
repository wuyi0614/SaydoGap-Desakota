# Base utils for LLM & Python I/O.  
# 
# Created at 20/04/2025, @Yi WU
#
# Updated at 08/12/2025, @Yi WU
#

from pathlib import Path
from loguru import logger

# set up the logger
DEFAULT_LOGGING_DIR = Path(__file__).parent / 'logs'
DEFAULT_LOGGING_FILE = DEFAULT_LOGGING_DIR / 'prompt_history.log'
DEFAULT_LOGGING_DIR.mkdir(parents=True, exist_ok=True)
logger.add(DEFAULT_LOGGING_FILE, format="{time} {level} {message}", level="INFO", rotation="100 MB", compression="zip")


def make_prompt_cache(messages: list[dict]):
    """Make a prompt cache."""
    for item in messages:
        msg = f"""{item['role']}: {item['content']}"""
        logger.info(msg)


def read_from_jsonl(file_path: Path, 
                    mapper: dict = None,
                    chunksize: int | None = None,
                    encoding: str = 'utf-8'):
    """Read the data from a JSONL file.

    Parameters
    ----------
    file_path : Path
        The path to the file.
    mapper : dict, optional
        The mapper that maps the fields to the new names, e.g., {'found': 'framework', 'within_text': 'text'}.
    chunksize : int | None, optional
        The number of lines to read from the file at a time, by default None.
    encoding : str, optional
        The encoding of the file, by default 'utf-8'.

    Returns
    -------
    Iterator[pd.DataFrame]
        An iterator of pandas DataFrames.
    """
    import pandas as pd
    
    file_path = Path(file_path)
    if not file_path.exists():
        logger.error(f"File not found: {file_path}")
        yield pd.DataFrame()

    mapper = mapper if mapper else {}
    try:
        df = pd.read_json(file_path, lines=True, chunksize=chunksize, encoding=encoding)
    except ValueError as e:
        logger.error(f"Error reading JSONL file: {e}")
        df = pd.DataFrame()

    if chunksize is None:
        yield df.rename(columns=mapper)
    else:
        for chunk in df:
            yield chunk.rename(columns=mapper)


def write_to_jsonl(item_or_items: dict | list[dict], 
                   file_path: Path, 
                   overwrite: bool = False, 
                   encoding: str = 'utf-8'):
    """Export the data into a JSONL file.

    Parameters
    ----------
    item_or_items : dict | list[dict]
        The item or items to write to the file.
    file_path : Path
        The path to the file.
    overwrite : bool, optional
        Whether to overwrite the file.
    encoding : str, optional
        The encoding of the file, default is 'utf-8'.

    Returns
    -------
    Path
        The output file path.
    """
    import orjson
    
    file_path = Path(file_path)
    # check if the file is a JSONL file
    if not file_path.suffix == '.jsonl':
        file_path = file_path.with_suffix('.jsonl')

    if isinstance(item_or_items, dict):
        item_or_items = [item_or_items]

    for i, item in enumerate(item_or_items):
        if overwrite:
            if i == 0:
                if file_path.exists():
                    file_path.unlink()
            
                with open(file_path, 'w', encoding=encoding) as f:
                    f.write(orjson.dumps(item).decode('utf-8') + '\n')
            else:
                with open(file_path, 'a', encoding=encoding) as f:
                    f.write(orjson.dumps(item).decode('utf-8') + '\n')
        
        else:
            if file_path.exists():
                with open(file_path, 'a', encoding=encoding) as f:
                    f.write(orjson.dumps(item).decode('utf-8') + '\n')
            elif i == 0 and not file_path.exists():
                with open(file_path, 'w', encoding=encoding) as f:
                    f.write(orjson.dumps(item).decode('utf-8') + '\n')
            else:
                with open(file_path, 'a', encoding=encoding) as f:
                    f.write(orjson.dumps(item).decode('utf-8') + '\n')

    return file_path
