# Prompt middlewares for LLM.  
#
# Created at 09/05-2025, @Yi WU
#
# Updated at 17/08-2025, @Yi WU
# 

from tokenizers import Tokenizer
from collections import defaultdict
from semantic_text_splitter import TextSplitter

from prompter.base import logger


# note: all functions in this file start with a `get_` prefix
def get_chunks_from_text(text: str, 
                         which_model: str = None,
                         overlap: int = 0,
                         min_length: int = 24,
                         chars_or_tokens: int = 512) -> list[str]:
    """Tokenize the text using the customised tokenizer derived from semantic-text-splitter.
    See: https://pypi.org/project/semantic-text-splitter/

    Parameters
    ----------
    text : str
        The text to tokenize.
    which_model : str, optional
        The model to use, e.g., 'hf:bert-base-uncased' or 'tiktoken:gpt-3.5-turbo' or None.
    overlap : int, optional
        The overlap of the text chunks, by default 0.
    min_length : int, optional
        The minimum length of the input text, by default 24.
    chars_or_tokens : int, optional
        The number of characters or tokens to tokenize, by default 512; characters are only used for the base tokenizer.

    Returns
    -------
    list[str]
        The list of text chunks.
    """ 
    if len(text) < min_length:
        logger.warning(f'ShortTextWarning({len(text)}): {text}')
        return []

    if which_model.startswith('hf:'):
        model_name = which_model.split(':')[1]
        tokenizer = Tokenizer.from_pretrained(model_name)
        splitter = TextSplitter.from_huggingface_tokenizer(tokenizer, capacity=chars_or_tokens, overlap=overlap)

    elif which_model.startswith('tiktoken:'):
        model_name = which_model.split(':')[1]
        splitter = TextSplitter.from_tiktoken_model(model_name, capacity=chars_or_tokens, overlap=overlap)

    else:
        # set trim=False for markdown texts
        splitter = TextSplitter(capacity=chars_or_tokens, overlap=overlap, trim=True)

    return splitter.chunks(text)


def get_text_by_page(contlist: list[dict]) -> dict[int, str]:
    """Get the text of a specific page from the content list.

    Parameters
    ----------
    contlist : list[dict]
        A list of dictionaries containing the content list.

    Returns
    -------
    dict[int, str]
        A dictionary containing the text of each page.
    """
    text_by_page = defaultdict(str)
    for item in contlist:
        if item['type'] == 'image':
            continue
        
        if item['type'] == 'text':
            text_by_page[item['page_idx']] += '\n' + item['text']

    return text_by_page
