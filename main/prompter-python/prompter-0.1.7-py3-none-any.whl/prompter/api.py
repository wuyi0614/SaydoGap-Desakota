# Read-to-use APIs based on the prompt module.
#
# Created at 18/10/2025, @Yi WU
#
# Updated at 18/10/2025, @Yi WU
#

from abc import ABC
from pydantic import BaseModel


class BaseAPI(ABC):
    
    """A base class for APIs."""
    
    prompt_model: object
    json_model: BaseModel
    fitted: bool
    
    def __init__(self,
                 which_model: str,
                 system_prompt: str,
                 thinking: bool = False,
                 json_model: BaseModel = None,
                 multi_round: bool = False,
                 verbose: bool = False,
                 **kwargs):
        
        from prompter.prompt import BasePromptModel
        
        self.prompt_model = BasePromptModel(which_model=which_model,
                                            system_prompt=system_prompt,
                                            thinking=thinking,
                                            json_model=json_model,
                                            multi_round=multi_round,
                                            verbose=verbose,
                                            **kwargs)
        self.fitted = True

    def fit(self, system_prompt: str, **kwargs):
        """Use .fit() to update the system prompt."""
        self.prompt_model.update_system_prompt(system_prompt)
        self.fitted = True
        return self

    def transform(self, texts_or_prompted_texts: str | list[str], **kwargs):
        """
        Transform the input texts or prompted texts using the prompt model.
        Subclasses may override this method for custom input/output handling.
        """
        if not self.fitted:
            raise RuntimeError("Must call fit() first.")
        
        return self.prompt_model.prompt(texts_or_prompted_texts)

    def fit_transform(self, texts_or_prompted_texts: str | list[str], **kwargs):
        if not self.fitted:
            raise RuntimeError("Must call fit() first.")
        
        # Subclass should override _prepare_user_prompt and _process_response as needed
        return self.transform(texts_or_prompted_texts, **kwargs)


class RunTranslationAPI(BaseAPI):
    
    """
    Translation API for prompted & structured language translation. This API supports chunking if the chunking parameter is set to `True`.
    """
    
    json_model: BaseModel
    
    def __init__(self, 
                 which_model: str,
                 chunking: bool = True,
                 thinking: bool = False,
                 system_prompt: str = None,
                 multi_round: bool = False,
                 verbose: bool = False, 
                 **kwargs):
        
        """Initialize the translation API powered by the prompt model.
        
        Parameters
        ----------
        which_model: str
            The model to use, e.g., 'ollama+qwen3:32b' or 'openai+gpt-4o-mini'
        chunking: bool, optional
            Whether to enable chunking, by default True
        thinking: bool, optional
            Whether to enable thinking, by default False
        system_prompt: str, optional
            The system prompt to use, by default None
        multi_round: bool, optional
            Whether to enable multi-round chatting, by default False
        verbose: bool, optional
            Whether to enable verbose logging, by default False
        **kwargs: dict, optional
            Additional keyword arguments to pass to the parent class
        """
        
        from pydantic import create_model, Field
        from prompter.prompt import TranslationPromptModel
        
        self.chunking = chunking
        # setup the standard JSON model for the structured translation response
        json_model = create_model(
            "TranslationResponseModel",
            original_language=(str, Field(description="The language of the untranslated text, must be abbreviated in standard format (e.g., en, de, jp, zh)")),
            translation=(str, Field(description="The translated text"))
        )
        self.prompt_model = TranslationPromptModel(
            which_model=which_model,
            thinking=thinking,
            multi_round=multi_round,
            json_model=json_model,
            verbose=verbose,
            **kwargs
        )

    def transform(self, texts_or_prompted_texts: str | list[str], **kwargs):
        """Transform the input texts or prompted texts using the prompt model. Specify the following parameters for chunking:
           - tokenizer_model: str
             The tokenizer model to use, e.g., 'hf:bert-base-uncased' or 'tiktoken:gpt-4o-mini'
           - overlap: int
             The overlap of the text chunks, by default 0
           - min_length: int
             The minimum length of the text chunks, by default 24
           - max_tokens: int
             The maximum number of tokens to use, by default 512
        """
        from tqdm import tqdm
        
        if isinstance(texts_or_prompted_texts, str):
            texts_or_prompted_texts = [texts_or_prompted_texts]
        
        if self.chunking:
            tokenizer_model = kwargs.get('tokenizer_model', 'tiktoken:gpt-3.5-turbo')
            overlap = kwargs.get('overlap', 10)
            min_length = kwargs.get('min_length', 24)
            max_tokens = kwargs.get('max_tokens', 512)
            chunks = self.prompt_model._chunk(texts_or_prompted_texts, 
                                              tokenizer_model=tokenizer_model,
                                              overlap=overlap,
                                              min_length=min_length,
                                              max_tokens=max_tokens)
        else:
            chunks = texts_or_prompted_texts
        
        translated = []  # note: return a list of paired (original, translated) results
        for text in tqdm(chunks, total=len(chunks), desc="Run TranslationAPI" ,leave=True):
            response = self.prompt_model.prompt(text)
            translated.append([text, response.response])
        
        return translated


if __name__ == "__main__":
    # 用中文的例子来测试 RunTranslationAPI
    from prompter.api import RunTranslationAPI

    # 定义要翻译的中文句子列表
    chinese_sentences = [
        "这是一个测试。",
        "人工智能正在改变世界。",
        "请将这句话翻译成英文。",
        "编程可以提高你的逻辑思维能力。"
    ]

    # 创建翻译 API 实例
    translation_api = RunTranslationAPI(
        which_model='ollama+qwen3:4b',  # 假设你已经配置了 openai apikey 和模型
        chunking=False,
        thinking=True,
        multi_round=False,
        verbose=True,
    )

    assert len(translation_api.prompt_model.chat_model.messages) == 2, "系统提示词应该被添加到消息历史中"
    results = translation_api.transform(chinese_sentences)

    # 输出结果
    print("翻译结果：")
    for orig, trans in results:
        print(f"原文: {orig}\n译文: {trans}\n{'-'*30}")
