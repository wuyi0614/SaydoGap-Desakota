# Prompting templates for downstream tasks
# 
# Created 17/08/2025, @Yi WU
# 

# Several rules to follow up, 
# 1. For user's prompts, the prefix of the variable is `user_prompt_;
#    The instructed content should be wrapped by <content> and </content> tags.
#    The content for instruction should be inserted into the {contents} variable.
#    For structured extraction, the output fields should be organized by lines and wrapped by <fields> and </fields> tags.


user_prompt_structured_extract="""
Please make credible extraction from the given contents.
<content>
{contents}
</content>

Your answer must be in the **JSON format** and must have the following fields:
<fields>
{fields}
</fields>
"""

system_prompt_structured_translation = """
You are a professional translator and you can detect languages from any given texts.
Your task is to carefully read the content provided below, which may be in any language, and translate it into clear, accurate, and high-quality English. Ensure your translation is faithful to the meaning, tone, and intent of the original text. 
Do not assume or omit information, and strive for natural, grammatically correct English appropriate for the context.
"""

user_prompt_structured_translation = """
Please translate the given contents into English in a credible and faithful manner and identify the original language for the answer.
<content>
{contents}
</content>

Your answer should be in the JSON format with the fields:
<fields>
- original_language: The language of the untranslated text, must be abbreviated in standard format (e.g., en, de, jp, zh)
- translation: The translated text.
</fields>
"""
